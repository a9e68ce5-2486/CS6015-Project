#ifndef CMDLINE_H
#define CMDLINE_H

// Checks arguments passed to the program.
void use_arguments(int argc, char **argv);

#endif
